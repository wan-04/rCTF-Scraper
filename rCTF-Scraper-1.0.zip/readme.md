# rCTF-Scraper

## Installation

```
git clone https://github.com/wan-04/rCTF-Scraper
cd rCTF-Scraper
pip install -r requirements.txt
```

## Usage

- Ex:

```
URL: https://damctf.xyz/
token: https://damctf.xyz/login?token=73S4o8XKcU8wtTREEk6u6F06N7pBllJngPqoAsNFSbHPWJIYc83G33bODovLQsyW2oI%2BDXE2egl%2B...
```

## Credits

- [CTFdScraper](https://github.com/hanasuru/CTFdScraper)
- [Eruditus - CTF helper bot](https://github.com/hfz1337/Eruditus)
